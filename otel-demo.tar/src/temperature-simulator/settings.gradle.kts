rootProject.name = "tempsimulator"
