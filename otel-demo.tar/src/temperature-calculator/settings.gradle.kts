rootProject.name = "tempcalculator"
